OPTIMIZED SOURCE FILES - general_coat1
=======================================

Original decompiled vertex total (SMD mesh attributes): 77,166
Optimized decompiled vertex total (same counting method): 63,990
Vertices reduced: 13,176
Intended limit: fewer than 65,000 vertices.

Changes:
1. The 10 rank files shared exactly 2,004 identical rank-backing triangles
   (1,144 vertices). Those triangles are now stored only once inside
   c_t9_cp_rus_kgb_guard_body_longcoat.smd, a required, always-visible
   bodygroup. All 10 rank-specific insignia/buttons are unchanged.
2. Conservative interior-edge simplification of hands_white_nogloves.smd
   and hands_ger_woolgloves_fingerless.smd. UV boundaries, material seams,
   most skin-weight differences, and original bone indices are protected.
   The facial mesh, flexes, rig, accessories and other geometry were NOT decimated.
3. Fixed an invalid control character in the QC for right_lid_raiser.

HOW TO USE
1. Back up your original decompiled files first.
2. In Crowbar, choose the Compile tab, browse to general_coat1.qc
   INSIDE this optimized folder, and compile with your Source/GMod studiomdl.
3. Install the resulting model in your usual Garry's Mod addon location;
   keep your existing model materials/textures from the original addon.
4. Verify final VVD LOD0 vertices and test every bodygroup, every hand style,
   the coat skeleton, facial expressions and all 10 ranks in the game.

IMPORTANT: This is an edited DECOMPILED SOURCE package, not a compiled .mdl.
The vertex count is calculated from the decompiled SMD data and matched the
original model's .vvd LOD0 count exactly (77,166), but the final vertex total
and successful compilation CANNOT be guaranteed until recompilation.
No manual Blender work is necessary for the supplied edits.
