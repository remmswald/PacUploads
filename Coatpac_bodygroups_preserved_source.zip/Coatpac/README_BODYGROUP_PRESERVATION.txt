BODYGROUP-PRESERVING OPTIMISATION FOR PAC3
==========================================

Original decompiled model: Coatpac.zip
New decompiled SMD source vertex tally: 61,108 (original 77,166)
Removed: 16,058 source mesh vertices (~20.8%).

WHAT CHANGED
- All original 10 rank bodygroup options remain SEPARATE, and their common backings remain INSIDE each variant (rather than being moved into the coat).
- Rank buttons / insignia polygons are byte-for-byte identical in source vertex data and triangle order.
- No bodygroups, SMD filenames, skeleton definitions, weights on retained vertices, or material names changed.
- The facial SMD, flex VTA, ragdoll/physics SMD, and animations are unchanged.
- Local edge-collapse simplification of other meshes (e.g., coat, gloves, trousers, caps) reduces geometry while protecting UV seams and avoiding face flips.
- The QC was kept the same except for repairing the corrupted decompiler flexcontroller token (right_lid_raiser).

IMPORTANT
This is Crowbar *source* (SMD/QC), NOT a directly loadable PAC3 model.
In Crowbar -> Compile select general_coat1.qc, compile for Garry's Mod, and use the newly produced .mdl/.vvd/.vtx/.phy files (not the previously compiled files).
Source vertex counts closely tracked the previous compiled model, but the final compiled VVD count must be confirmed after compilation.
PAC3 ZIP uploads must use ZIP method STORE (no compression), unlike this source distribution ZIP.
No in-game/StudioMDL compile testing has been performed in this environment.

Validation: all original model sources present; bodygroup command declarations unchanged; all 10 rank backings match; every rank variant's buttons are unchanged; all original materials are retained; the face/flex and skeleton definitions remain unchanged.
