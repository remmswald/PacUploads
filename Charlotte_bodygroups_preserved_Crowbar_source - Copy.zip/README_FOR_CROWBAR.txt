CHARLOTTE2 - BODYGROUP-PRESERVING SOURCE OPTIMISATION
===================================================
THIS IS NOT A PAC3 MODEL ZIP. Decompile/source files must be compiled in Crowbar first.

Changes made:
 - QC, bodygroup names/order/options, bones, animation SMDs, flex/face, hands, shoes and physics SMD are byte-for-byte unchanged.
 - Geometry inside s1.smd, s2.smd, s3.smd, s4.smd, g1.smd, and g2.smd was simplified separately.
 - No hair/clothing variant removed or merged. Original UV and skinweight records remain from the source, for surviving vertices.
 - Source-model unique SMD vertex records: 110,482 original -> 60,138 optimised.
 - Source vertex record estimate only. Actual compiled VVD vertex count may differ; verify after compile.

NEXT STEPS:
 1. Extract this ZIP into an ordinary folder.
 2. Open Crowbar -> Compile, choose Charlotte/charlotte2.qc, choose Garry's Mod game and compile.
 3. Check the compiled model in Garry's Mod and inspect all bodygroups, both clothing options and hairstyles.
 4. Upload compiled charlotte2.mdl, charlotte2.vvd, charlotte2.dx80.vtx,
    charlotte2.dx90.vtx, and charlotte2.phy here so they can be packaged for PAC3
    using ZIP method 0 (Store).

NOTE: This is not visually tested in Garry's Mod. The appearance of hair and clothing
can change due to the significant geometry reduction, and compilation may fail.
